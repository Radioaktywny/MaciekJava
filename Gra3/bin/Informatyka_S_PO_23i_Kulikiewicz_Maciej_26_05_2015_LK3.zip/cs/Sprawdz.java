package cs;

public class Sprawdz {
	try
	{
		throw new Exception();
	}
	catch(Exeption e)
	{
		return 1;
	}
	finally 
	{return 2;
	}
}

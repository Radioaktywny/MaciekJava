package cs;

import java.util.Scanner;


/**
 * 
 * @author Maciej Kulikiewicz
 *
 */
public abstract class Postac implements Sterowanie{
	
	/**
	 * @param nazwa_postaci nazwa postaci
	 * @param zycie
	 * @param lewy przycisk myszy
	 * @param znak1 zczytany znak
	 */
	//Scanner znak1 =new Scanner(System.in);
	protected boolean postac;
	protected String nazwa_postaci;
	protected int zycie;
	public boolean lewy_przycisk_myszy;
	public Postac(int zycie, String nazwa_postaci) {
		this.nazwa_postaci=nazwa_postaci;
		this.zycie=zycie;
	}
	/**
	 * Metoda odpowiedzialna za strzelanie
	 */
	int cos=14;
	void celuj()
	{
		if()
	}
	public void strzelaj()
	{	
		if (lewy_przycisk_myszy==true && postac == true)
		{
		
		}
	}
	
	/**
	 * @param x wspolrzedne x'owe
	 * @param y wspolrzedne y'owe
	 * @param znak aktualnie nacisniety znak
	 */
	int x;
	int y;
	Scanner znak1 =new Scanner(System.in);
	Sprawdz(znak1);
	private void Sprawdz(Scanner znak)
	{
		try
		{
			if ( znak.next().charAt(0) == 'k');
		} 	
		catch(Exception e)
		{
			System.out.println("Nie poprawny klawisz");	
		};
	}
	
	/**
	 * Metoda opisuje chodzenie w prz�d
	 */

	public void idz_do_przodu() {
		
		if(znak1.next().charAt(0) == 'w')
		{
			y++;
	//		System.out.println("jea");
		}
	}
	/**
	 * Metoda opisuje chodzenie w ty�
	 */
	public void idz_do_tylu() {
		if(znak1.next().charAt(0) == 's')
		{
			y--;
		}
		
	}
	/**
	 * Metoda opisuje chodzenie w prawo
	 */
	public void idz_w_prawo() {
		if(znak1.next().charAt(0) == 'd')
		{
			x++;
		}
		
	}
	/**
	 * Metoda opisuje chodzenie w lewo
	 */
	public void idz_w_lewo() {
		if(znak1.next().charAt(0) == 'a')
		{
			x--;
		}
	}
	}


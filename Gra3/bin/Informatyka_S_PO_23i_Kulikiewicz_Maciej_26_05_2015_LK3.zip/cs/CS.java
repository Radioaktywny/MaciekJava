package cs;
/**
 * 
 * @author Maciej Kulikiewicz
 *
 */
public class CS  {
	
	
	public static void main(String[] args) 
	{
		Gracz maciek=new Gracz();
		maciek.idz_do_przodu();
		
	
	}


}

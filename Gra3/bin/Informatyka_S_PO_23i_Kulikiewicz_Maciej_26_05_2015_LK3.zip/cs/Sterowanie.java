package cs;
/**
 * 
 * @author Maciej Kuliekiewicz
 *
 */
public interface Sterowanie {
	
	void idz_do_przodu();
	void idz_do_tylu();
	void idz_w_prawo();
	void idz_w_lewo();
}

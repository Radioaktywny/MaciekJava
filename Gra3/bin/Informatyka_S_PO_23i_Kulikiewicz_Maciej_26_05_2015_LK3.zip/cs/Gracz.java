package cs;

/**
 * @author Maciej Kulikiewicz
 */
public class Gracz extends Postac{
	/**
	 * @param kewlar
	 * @param Ranga ranga gracza
	 */
	protected int kewlar;
	protected int steam_id;
	protected String Ranga;
	/**
	 * konstruktor 4 parametrowy przkazujacy
	 * @param nazwe
	 * @param Randa
	 * @param zycie
	 * @param kewlar
	 */
	protected Gracz(String nazwa_postaci, String Ranga, int zycie , int kewlar )
	{
		super(zycie, nazwa_postaci);
		this.kewlar=kewlar;
		this.Ranga=Ranga;
	}
	/**
	 * Kosntruktor domyslny
	 */
	public Gracz()
	{
		this("Nieznana" , "Silver 1 " , 100 , 100);
	}
	
}


package bron;

public interface BronI {
	public void strzelaj(int x, int y , int z);

}

package cs;

public class ExceptionMy extends Exception
{

}
